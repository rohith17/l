package com.flp.pms.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.SubCategory;
import com.google.gson.Gson;
public class ProductServlet extends HttpServlet {

       
	private static final long serialVersionUID = 1L;
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("application/json");
		IProductDao pdao=new ProductDaoImplForMap();
		Gson myJson=new Gson();
		
		String action=request.getParameter("action");
		
		if(action.equalsIgnoreCase("category")){
		List<Category> categories=pdao.getAllCategory();
	     String categoryJson=myJson.toJson(categories);
	    out.println(categoryJson);
		}
		
		
		if(action.equalsIgnoreCase("subCategory")){
			List<SubCategory> subcategories=pdao.getAllSubCategory();
		     String subcategoryJson=myJson.toJson(subcategories);
		    out.println(subcategoryJson);
			}
			
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}
}
